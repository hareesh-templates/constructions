<!DOCTYPE html>
<html lang="en">
     <head>
     <title>Search</title>
     <meta charset="utf-8">
     <meta name = "format-detection" content = "telephone=no" />
     <link rel="icon" href="images/favicon.ico">
     <link rel="shortcut icon" href="images/favicon.ico" />
     <link rel="stylesheet" href="css/style.css">
     <script src="js/jquery.js"></script>
     <script src="js/jquery-migrate-1.1.1.js"></script>
     <script src="js/script.js"></script> 
     <script src="js/superfish.js"></script>
     <script src="js/jquery.ui.totop.js"></script>
     <script src="js/jquery.equalheights.js"></script>
     <script src="search/search.js"></script>
     <script src="js/jquery.mobilemenu.js"></script>
     <script src="js/jquery.easing.1.3.js"></script>

     <script>

    
      $(document).ready(function(){
        $().UItoTop({ easingType: 'easeOutQuart' });
      }); 
    
     
     </script>
     <!--[if lt IE 8]>
       <div style=' clear: both; text-align:center; position: relative;'>
         <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
           <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
         </a>
      </div>
    <![endif]-->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <link rel="stylesheet" media="screen" href="css/ie.css">


    <![endif]-->
     </head>
<body>
<!--==============================header=================================-->
<div class="main">
     <div class="head-1">  
     <div class="container_12">
           <div class="grid_12">
         <header>
               <h1><a href="index.html"><img src="images/logo.png" alt=""></a></h1>
               <div class="div-search">
                    <form id="search" action="search.php" method="GET" accept-charset="utf-8">
                       <input type="text" name="s" />
                       <a onclick="document.getElementById('search').submit()"  class="search_button"></a>
                    </form>
          </div>
               <div class="clear"></div>
             <nav> 
               <div class="inner">
                <ul class="sf-menu">
                    <li id="first-li"><a href="index.html">Home</a></li>
                     <li><a href="index-1.html">About</a>
                            <ul>
                         <li><a href="#">history</a></li> 
                         <li><a href="#">news</a>
                               <ul>
                              <li><a href="#">latest</a></li>
                              <li><a href="#">archive</a></li>
                           </ul> 
                             </li>
                         <li><a href="#">testimonials</a></li>
                       </ul>
                         </li>
                     <li><a href="index-2.html">projects</a> </li>
                     <li><a href="index-3.html">services</a></li>
                     <li class=""><a href="index-4.html">Blog</a></li> 
                         <li id="last-li"><a href="index-5.html">Contacts</a></li> 
                 </ul>
                     <div class="clear"></div>
               </div>
              </nav>
      </header></div>
         </div>    </div> 
     
    <!--==============================content================================-->
  <section id="content">         
    <div class="container_12">
      <div class="wrapper">
       <div class="grid_12">
        <h2 class="color padd-1">Search result:</h2>

			   <div id="search-results"></div>
         </div>
            
            
      </div><!--the end of wrapper-->
    </div>
  </section>
  <!--==============================footer=================================-->  
    <div class="div-indent"></div>  
</div>
  <footer>
      <div class="main-footer">
    <div class="container_12"><div class="grid_6 ff_right">
                    <div class="pages">
                      <a href="index.html">Home</a>
                      <a href="index-1.html">about</a>
                      <a href="index-2.html">projects</a>
                      <a href="index-3.html">services</a>
                      <a href="index-4.html" class="">blog</a>
                      <a href="index-5.html">contacts</a>
                    </div>
                </div>
              <div class="grid_6">
                    <p class="txt-up">
                        <a href="index.html"><img src="images/logo-1.png" alt=""></a>
                      <span>&nbsp;&nbsp;&copy; 2013&nbsp;|&nbsp;<a href="index-6.html">Privacy Policy</a> <br></span>
                    </p>
                    <div class="icons">
                       <a href="#" id="icon"></a>
                       <a href="#" id="icon-1"></a>
                       <a href="#" id="icon-2"></a>
                       <a href="#" id="icon-3"></a>
                       <a href="#" id="icon-4"></a>
                    </div>
              </div>
                
                <div class="clear"></div>
        </div>
      </div>  
  </footer> 
</body>
</html>