<!DOCTYPE html>
<html lang="en">
<head>
<title>search results</title>
<meta charset="utf-8">
<meta name = "format-detection" content = "telephone=no" />
<link rel="icon" href="img/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
<meta name="description" content="Your description">
<meta name="keywords" content="Your keywords">
<meta name="author" content="Your name">   
<meta name = "format-detection" content = "telephone=no" /> 
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="font/font-awesome.css">
<!--JS-->
<script src="js/jquery.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="search/search.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.ui.totop.js"></script> 
<!--[if lt IE 8]>
    <div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg"border="0"alt=""/></a></div>  
<![endif]-->
<!--[if lt IE 9]>
  <script src="js/html5shiv.js"></script>
<![endif]-->
</head>
<body>
<div class="global">
<!--header-->
<header>
    <div class="container">
        <h1 class="brand"><a href="index.html"><img src="img/logo.png" alt=""></a></h1>
        <div class="navbar navbar_ clearfix">
            <div class="navbar-inner">      
                <div class="clearfix">
                    <div class="nav-collapse nav-collapse_ collapse">
                        <ul class="nav sf-menu clearfix">
                            <li><a href="index.html">Main Page<em></em></a><strong></strong></li> 
                            <li class="sub-menu"><a href="index-1.html">About Us<span></span><em></em></a><strong></strong>
                                <ul class="submenu">
                                    <li><a href="#">Profile<span></span></a>
                                        <ul class="submenu-1">
                                            <li><a href="#">Lorem ipsum</a></li>
                                            <li><a href="#">Sit amet</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">History</a></li>
                                    <li><a href="#">Team</a></li>
                                    <li><a href="#">Testimonials</a></li>
                                </ul>
                            </li> 
                            <li><a href="index-2.html">Services<em></em></a><strong></strong></li>
                            <li><a href="index-3.html">Solutions<em></em></a><strong></strong></li>
                            <li><a href="index-4.html">Contacts<em></em></a></li>                     
                        </ul>
                    </div>                                                                                                                
                </div>
            </div>  
        </div>
    </div>
</header>
<figure class="bg-picture"></figure>
<!--content-->
<div class="container padBot2">
    <div class="row">
        <article class="span12">
            <h2>Search result:</h2>
            <div id="search-results"></div>
        </article>
    </div>
</div>
</div>
<!--footer-->
<footer>
    <div class="container">
        <div class="row">
            <div class="clearfix pull-right">
                <article class="span3">
                    <h3>Latest Projects</h3>
                    <ul class="list2">
                        <li><a href="#">Praesent vestibulum molestie</a></li>
                        <li><a href="#">Aenean nonummy hendrerit mauris</a></li>
                        <li><a href="#">Phasellus porta</a></li>
                        <li><a href="#">Fusce suscipit varius micum</a></li>
                        <li><a href="#">Sociis natoque penatibus</a></li>
                    </ul>
                </article>
                <article class="span3">
                    <h3>8901 Marmora Road, <br>Glasgow, D04 89GR.</h3>
                    <p class="margBot">E-mail: <a href="#">mail@demolink.org</a></p>
                    <p>Call Us Free</p>
                    <p class="tel">1 800 234 56 78</p>
                </article>
                <article class="span3">
                    <ul class="follow_icon">
                        <li>
                            <span class="icon-twitter-sign"></span>
                            <a href="#">Follow Us on Twitter</a>
                        </li>
                        <li>
                            <span class="icon-facebook-sign"></span>
                            <a href="#">Like Us on Facebook</a>
                        </li>
                        <li>
                            <span class="icon-google-plus-sign"></span>
                            <a href="#">Find Us at Google+</a>
                        </li>
                        <li>
                            <span class="icon-linkedin-sign"></span>
                            <a href="#">Get Our LinkedIn</a>
                        </li>
                    </ul>
                </article>
            </div>
            <div class="clearfix pull-left">
                <article class="span2 foo_logo">
                     <figure><img src="img/foo_logo.png" alt=""></figure>
                     <p class="privacy">&copy; 2013 <span>|</span> <br><a href="index-5.html">Privacy Policy</a></p>
                </article>
            </div>
        </div>
    </div> 
    <em></em>
</footer>
<script src="js/bootstrap.js"></script>
</body>
</html>