function include(url){document.write('<script type="text/javascript" src="'+url+'"></script>')}

//------ base included scripts -------//
include('js/jquery.easing.js');
include('js/TMForm.js');
include('js/owl.carousel.js');

//------------------------------------//
if (!FJSCore.mobile) {
    if (!FJSCore.tablet){
        include('js/jquery-ui-1.10.3.custom.min.js');
    }
    include('js/hoverIntent.js');
    include('js/superfish.js'); 
    include('js/jquery.touchSwipe.min.js');
    include('js/tmMultimediaGallery.js');
} else{
    include('js/klass.min.js');
    include('js/code.photoswipe.jquery-3.0.5.js');
}

var $win = $(window),
    $doc = $(document),
    $body = $('body'),
    $fullGallery,
    $other_pages,
    $content_pages,
    galleryActive = false,
    galleryPageURL = 'gallery';

function initPlugins(){
    if (!FJSCore.tablet) {
        $fullGallery.tooltip({
            track: true
        });
    }

    var phSwipe = $("#Gallery a");
    phSwipe.on('click', function (e){ return false; });
    phSwipe.length && phSwipe.photoSwipe({jQueryMobileDialogHash: false});

    $other_pages.width($win.width() - $content_pages.width());
    
    initContactForm();
}

function toggleFullScreen() {
   if (!document.fullscreenElement &&    // alternative standard method
    !document.mozFullScreenElement && !document.webkitFullscreenElement) {  // current working methods
     if (document.documentElement.requestFullscreen) {
       document.documentElement.requestFullscreen();
     } else if (document.documentElement.mozRequestFullScreen) {
       document.documentElement.mozRequestFullScreen();
     } else if (document.documentElement.webkitRequestFullscreen) {
       document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
     }
   } else {
      if (document.cancelFullScreen) {
         document.cancelFullScreen();
      } else if (document.mozCancelFullScreen) {
         document.mozCancelFullScreen();
      } else if (document.webkitCancelFullScreen) {
        document.webkitCancelFullScreen();
      }
   }
}

function initFullGallery(){
    /*carousel*/
        var owl = $(".owl"); 
            owl.owlCarousel({
            items : 1, //10 items above 1000px browser width
            itemsDesktop : [995,1], //5 items between 1000px and 901px
            itemsDesktopSmall : [767, 1], // betweem 900px and 601px
            itemsTablet: [700, 1], //2 items between 600 and 0
            itemsMobile : [479, 1], // itemsMobile disabled - inherit from itemsTablet option
            navigation : true,
            pagination :  false
            });

    /*carousel2*/
        var owl = $(".owl1"); 
            owl.owlCarousel({
            items : 1, //10 items above 1000px browser width
            itemsDesktop : [995,1], //5 items between 1000px and 901px
            itemsDesktopSmall : [767, 1], // betweem 900px and 601px
            itemsTablet: [700, 1], //2 items between 600 and 0
            itemsMobile : [479, 1], // itemsMobile disabled - inherit from itemsTablet option
            navigation : true,
            pagination :  false
            });

    var tmt = 0;
    $fullGallery.tmMultimediaGallery({
        container: '.galleryContainer',
        animationSpeed: '1.2',
        autoPlayState: false,
        pagination: '.f_gal',
        outerPagination: true,
        paginationDisplay: true,
        controlDisplay: true,
        autoPlayTime: 12,
        alignIMG: 'top_right',
        mobile: FJSCore.tablet,
        mouseMove: true,
        onShowActions: function(){
            clearTimeout(tmt);
            tmt = setTimeout(function(){
                galleryActive = true;
                //alert(FJSCore.tablet);
            if ((navigator.userAgent.match(/MSIE/i)) || (navigator.userAgent.match(/rv:11.0/i)) || (FJSCore.tablet)) {
                     $(".navigation-holder1").delay(100).animate({'left':'20px'}, 600, "easeOutCubic");
                }
                else{

                     $(".navigation-holder1").delay(100).animate({'left':'0px'}, 600, "easeOutCubic");
                }
               
                $('.close-icon').removeClass('hideButton');
                $('.galleryContainer .navigation-holder').removeClass('hideButton');
            }, 1000);
            $('.zoom').addClass('hideButton');
            (!FJSCore.tablet) && $fullGallery.tooltip('enable');
        },
        onHideActions: function(){
            clearTimeout(tmt);
            setTimeout(function(){
                galleryActive = false;
            }, 1000);
            $('.zoom').removeClass('hideButton');
            $(".navigation-holder1").delay(100).animate({'left':'-500px'}, 600, "easeOutCubic");
            $('.close-icon').addClass('hideButton');
            $('.galleryContainer .navigation-holder').addClass('hideButton');
            (!FJSCore.tablet) && $fullGallery.tooltip('disable');
        },
        onBeforeChange: function(){
            galleryActive = false;
            $('#imageHolder').removeClass('animationDisable');
        },
        onAfterChange: function(){
            if (FJSCore.state === galleryPageURL) {
                galleryActive = true;
            } else {
                $fullGallery.trigger('setGalleryActivity','false');
            }
            $('#imageHolder').addClass('animationDisable');
        }
    });






    $('.fullscr-btn').on('click', function(){
        toggleFullScreen();
    });
}

function fromSplash(){
    $('#contentHolder, #other_pages').removeClass('splashState');
}
function toSplash(){
    $('#contentHolder, #other_pages').addClass('splashState');
}
$doc.on('changeState', function(e,d){
    if (!FJSCore.mobile) {
        switch (d) {
            case '':
                toSplash();
            break;
            default:
                fromSplash();
            break;
        }
    }
})



$(function(){
    if(FJSCore.mobile){
        $('#mobile-navigation > option').eq(2).remove();   
    } else {
        $('.mainNav').superfish({
            speed: 'fast'
        });
    }
    
    $fullGallery = $("#galleryHolder"); 
    $content_pages = $('#content');
    $other_pages = $('#other_pages');
    initPlugins();
    if (!FJSCore.mobile) initFullGallery();

    $content_pages
        .on('show','>*',function(e,d){
            $("h1").css({'margin-top':'30px'}).stop().delay(0).animate({'margin-top':'-120px'}, 400, "easeOutCubic");
             $(".mainNav").css({'margin-top':'120px'}).stop().delay(0).animate({'margin-top':'50px'}, 400, "easeOutCubic");

              if (FJSCore.tablet){
            $("h1").css({'margin-top':'0px'}).stop().delay(0).animate({'margin-top':'-20px'}, 400, "easeOutCubic");
             $(".mainNav").css({'margin-top':'0px'}).stop().delay(0).animate({'margin-top':'-50px'}, 400, "easeOutCubic");
              }
           
           
            $.when(d.elements)
                .then(function(){
                    initPlugins();
                    $win.trigger('resize');

                    d.curr
                        .addClass('active')                      
                        .stop()
                        .css({'display':'block', 'top': '-120%'})
                        .animate({
                            'top':0
                        },{
                            duration:1000
                        })
                })          
        })
        .on('hide','>*',function(e,d){
            $("h1").css({'margin-top':'-120px'}).stop().delay(50).animate({'margin-top':'30px'}, 600, "easeOutCubic");
             $(".mainNav").css({'margin-top':'50px'}).stop().delay(50).animate({'margin-top':'120px'}, 600, "easeOutCubic");

            if (FJSCore.tablet){
             $("h1").css({'margin-top':'-20px'}).stop().delay(50).animate({'margin-top':'0px'}, 600, "easeOutCubic");
             $(".mainNav").css({'margin-top':'-50px'}).stop().delay(50).animate({'margin-top':'0px'}, 600, "easeOutCubic");
              }
            
             
            $(this)
                .removeClass('active')
                .stop()
                .animate({
                    'top': '120%'
                },{
                    duration:500,
                    complete:function(){
                        $(this).css({'display':'none'});
                    }
                })
        });

if ((navigator.userAgent.match(/MSIE/i)) || (navigator.userAgent.match(/rv:11.0/i))) {
        $('html').addClass('ie');
    }

    function animateGallery(){
        var id = setInterval(function(){
            $fullGallery.trigger('resize');
        }, 33),
        id2 = setTimeout(function(){
            clearTimeout(id2);
            clearInterval(id);
            $fullGallery.trigger('resize');
            $body.trigger('resizeContent');
        }, 1200);
    }

    $other_pages
        .on('show','>*',function(e,d){
            $.when(d.elements)
                .then(function(){
                    d.curr.addClass('active');
                    $fullGallery.trigger('showGallery');

                    animateGallery();
                })          
        })
        .on('hide','>*',function(e,d){ 
            $(this).removeClass('active');
            $fullGallery.trigger('hideGallery');
            animateGallery();
        });

    $('#mobile-content')
        .on('show','>*',function(e,d){



            $.when(d.elements)
                .then(function(){
                    initPlugins();
                })          
        })
        .on('hide','>*',function(e,d){ 
        });
});
/*---------------------- end ready -------------------------------*/

$win
.on('resize', function(){
    if (FJSCore.state != galleryPageURL) {
        $other_pages.css({'width': $win.width() - $content_pages.width()});
    } else {
        $other_pages.css({'width':'100%'});
    }
})
.load(function(){ 
$("#year1").text((new Date).getFullYear()); 
    $("#webSiteLoader").fadeOut(300, 0, function(){
        $("#webSiteLoader").remove(); 
        $win.trigger('resize');

        if(($(window).height() < 769)){
             //$(".navigation-holder").css({'margin-top':'0px'}).stop().delay(0).animate({'margin-top':'0px'}, 0, "easeOutCubic");
              //$("h1").css({'margin-top':'20px'}).stop().delay(50).animate({'margin-top':'150px'}, 600, "easeOutCubic");
             }
             else{
              //$(".navigation-holder").css({'margin-top':'40px'}).stop().delay(50).animate({'margin-top':'200px'}, 600, "easeOutCubic");
               //$("h1").css({'margin-top':'30px'}).stop().delay(50).animate({'margin-top':'200px'}, 600, "easeOutCubic");  
            }
    });
 
    
    FJSCore.modules.responsiveContainer({
       
        container: '#content',
        elementsSelector: '#content>div',
        type: 'inner',
        defStates: '',
        activePageSelector: '.active' 
         
    });

    if(FJSCore.mobile){
        //----- mobile scripts ------//
        $('#mobile-header>*').wrapAll('<div class="container"></div>');
        $('#mobile-footer>*').wrapAll('<div class="container"></div>');
    }
    $win.trigger('afterload');
});
