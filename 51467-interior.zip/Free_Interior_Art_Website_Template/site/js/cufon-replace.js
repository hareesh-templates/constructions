Cufon.replace('#header .row-1 .fright ul li', { fontFamily: 'Myriad Pro Regular' });
Cufon.replace('h3', { fontFamily: 'Myriad Pro Light' });
Cufon.replace('h3 b', { fontFamily: 'Myriad Pro Regular' });